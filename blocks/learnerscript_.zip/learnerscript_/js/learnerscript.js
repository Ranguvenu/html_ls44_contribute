function menuplugin(event, args) {
    location.href = args.url + document.getElementById('menuplugin').value;
}