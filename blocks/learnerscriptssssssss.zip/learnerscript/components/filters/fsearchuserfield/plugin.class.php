<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * A Moodle block to create customizable reports.
 *
 * @package   block_learnerscript
 * @copyright 2023 Moodle India Information Solutions Private Limited
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
namespace block_learnerscript\lsreports;
use block_learnerscript\local\pluginbase;
use block_learnerscript\local\ls;
/**
 * User field search
 */
class plugin_fsearchuserfield extends pluginbase {
    /** @var mixed $singleselection  */
    public $singleselection;
    /**
     * User field search init function
     */
    public function init() {
        $this->form = true;
        $this->unique = true;
        $this->singleselection = true;
        $this->fullname = get_string('fsearchuserfield', 'block_learnerscript');
        $this->reporttypes = ['users'];
    }
    /**
     * Summary
     * @param  object $data
     * @return string
     */
    public function summary($data) {
        return $data->field;
    }
    /**
     * Execute
     * @param string $finalelements Final elements
     * @param object $data Filter data
     * @return array|object
     */
    public function execute($finalelements, $data) {
        if ($this->report->type == 'sql') {
            return $this->execute_sql($finalelements, $data);
        }

        return $this->execute_users($finalelements, $data);
    }
    /**
     * Sql query execution
     * @param object $finalelements Element
     * @param object $data data
     * @return object
     */
    private function execute_sql($finalelements, $data) {
        $filterfuserfield = optional_param('filter_fuserfield_' . $data->field, 0, PARAM_RAW);
        $filter = clean_param(base64_decode($filterfuserfield), PARAM_TEXT);

        if ($filterfuserfield && preg_match("/%%FILTER_USERS:([^%]+)%%/i", $finalelements, $output)) {
            $replace = ' AND ' . $output[1] . ' LIKE ' . "'%$filter%'";
            return str_replace('%%FILTER_USERS:' . $output[1] . '%%', $replace, $finalelements);
        }

        return $finalelements;
    }
    /**
     * Users query execution
     * @param object $finalelements Final element
     * @param object $data Users data
     * @return array
     */
    private function execute_users($finalelements, $data) {
        global $remotedb;

        $filterfuserfield = optional_param('filter_fuserfield_' . $data->field, 0, PARAM_RAW);
        if ($filterfuserfield) {
            // Function addslashes is done in clean param.
            $filter = clean_param(base64_decode($filterfuserfield), PARAM_CLEAN);
            if (strpos($data->field, 'profile_') === 0) {
                $conditions = ['shortname' => str_replace('profile_', '', $data->field)];
                if ($fieldid = $remotedb->get_field('user_info_field', 'id', $conditions)) {
                    list($usql, $params) = $remotedb->get_in_or_equal($finalelements);
                    $sql = "fieldid = ? AND data LIKE ? AND userid $usql";
                    $params = array_merge([$fieldid, "%$filter%"], $params);

                    if ($infodata = $remotedb->get_records_select('user_info_data', $sql, $params)) {
                        $finalusersid = [];
                        foreach ($infodata as $d) {
                            $finalusersid[] = $d->userid;
                        }
                        return $finalusersid;
                    }
                }
            } else {
                list($usql, $params) = $remotedb->get_in_or_equal($finalelements);
                $sql = "$data->field LIKE ? AND id $usql";
                $params = array_merge(["%$filter%"], $params);
                if ($elements = $remotedb->get_records_select('user', $sql, $params)) {
                    $finalelements = array_keys($elements);
                }
            }
        }
        return $finalelements;
    }
    /**
     * Print filter
     * @param  object $mform Form data
     * @param  object $data Form data
     */
    public function print_filter(&$mform, $data) {
        global $remotedb, $CFG;

        $columns = $remotedb->get_columns('user');
        $filteroptions = [];
        $filteroptions[''] = $this->singleselection ?
                        get_string('filter_all', 'block_learnerscript') : get_string('select') .' '. get_string($data->field);

        $usercolumns = [];
        foreach ($columns as $c) {
            $usercolumns[$c->name] = $c->name;
        }

        if ($profile = $remotedb->get_records('user_info_field')) {
            foreach ($profile as $p) {
                $usercolumns['profile_' . $p->shortname] = $p->name;
            }
        }
        $reportclassname = 'block_learnerscript\lsreports\report_' . $this->report->type;
        $reportclass = new $reportclassname($this->report);

        if ($this->report->type == 'sql') {
            $userlist = array_keys($remotedb->get_records('user'));
        } else {
            $components = (new ls)->cr_unserialize($this->report->components);
            $conditions = array_key_exists('conditions', $components) ?
                    $components['conditions'] :
                    null;
            $userlist = $reportclass->elements_by_conditions($conditions);
        }
        if (!empty($userlist)) {
            if (strpos($data->field, 'profile_') === 0) {
                $conditions = ['shortname' => str_replace('profile_', '', $data->field)];
                if ($field = $remotedb->get_record('user_info_field', $conditions)) {
                    $selectname = $field->name;

                    list($usql, $params) = $remotedb->get_in_or_equal($userlist);
                    $sql = "SELECT DISTINCT(data) as data FROM {user_info_data} WHERE fieldid = ? AND userid $usql";
                    $params = array_merge([$field->id], $params);

                    if ($infodata = $remotedb->get_records_sql($sql, $params)) {
                        $finalusersid = [];
                        foreach ($infodata as $d) {
                            $filteroptions[base64_encode($d->data)] = $d->data;
                        }
                    }
                }
            } else {
                $selectname = get_string($data->field);

                list($usql, $params) = $remotedb->get_in_or_equal($userlist);
                $sql = "SELECT DISTINCT(" . $data->field . ") as ufield FROM {user} WHERE id $usql ORDER BY ufield ASC";
                if ($rs = $remotedb->get_recordset_sql($sql, $params)) {
                    foreach ($rs as $u) {
                        $filteroptions[base64_encode($u->ufield)] = $u->ufield;
                    }
                    $rs->close();
                }
            }
        }

        $select = $mform->addElement('select', 'filter_fuserfield_' . $data->field, $selectname, $filteroptions,
        ['data-select2' => 1]);
        $select->setHiddenLabel(true);
        $mform->setType('filter_fuserfield_' . $data->field, PARAM_INT);
    }

}
