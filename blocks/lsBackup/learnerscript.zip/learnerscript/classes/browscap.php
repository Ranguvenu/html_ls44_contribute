<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * A Moodle block for creating customizable reports
 * @package   block_learnerscript
 * @copyright 2023 Moodle India Information Solutions Private Limited
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
/**
 * Browscap for displaying geographical dahsboard reports.
 */
class block_learnerscript_browscap {
    /**
     * Current version of the class.
     */
    const VERSION = '2.1.1';

    /**
     * Current version of the cache system
     */
    const CACHE_FILE_VERSION = '2.1.0';

    /**
     * UPDATE_FOPEN: Uses the fopen url wrapper (use file_get_contents).
     */
    const UPDATE_FOPEN     = 'URL-wrapper';
    /**
     * UPDATE_FSOCKOPEN: Uses the socket functions (fsockopen).
     */
    const UPDATE_FSOCKOPEN = 'socket';
    /**
     * UPDATE_CURL: Uses the cURL extension.
     */
    const UPDATE_CURL      = 'cURL';
    /**
     * UPDATE_LOCAL: Updates from a local file (file_get_contents).
     */
    const UPDATE_LOCAL     = 'local';

    /**
     * Options for regex patterns.
     *
     * REGEX_DELIMITER: Delimiter of all the regex patterns in the whole class.
     */
    const REGEX_DELIMITER               = '@';
    /**
     * Options for regex patterns.
     *
     * REGEX_MODIFIERS: Regex modifiers.
     */
    const REGEX_MODIFIERS               = 'i';
    /**
     * Options for regex patterns.
     *
     * COMPRESSION_PATTERN_START: Compression modifiers.
     */
    const COMPRESSION_PATTERN_START     = '@';
    /**
     * Options for regex patterns.
     *
     * COMPRESSION_PATTERN_DELIMITER: Compression Delimiter.
     */
    const COMPRESSION_PATTERN_DELIMITER = '|';

    /**
     * The values to quote in the ini file
     */
    const VALUES_TO_QUOTE = 'Browser|Parent';

    /**
     * The version key
     */
    const BROWSCAP_VERSION_KEY = 'GJK_Browscap_Version';

    /**
     * The headers to be sent for checking the version and requesting the file.
     */
    const REQUEST_HEADERS = "GET %s HTTP/1.0\r\nHost: %s\r\nUser-Agent: %s\r\nConnection: Close\r\n\r\n";

    /**
     * how many pattern should be checked at once in the first step
     */
    const COUNT_PATTERN = 100;

    /**
     * @var $remoteiniurl: The location from which download the ini file.
     *                     The placeholder for the file should be represented by a %s.
     */
    public $remoteiniurl = 'http://browscap.org/stream?q=PHP_BrowscapINI';
    /**
     * @var $remoteverurl: The location to use to check out if a new version of the
     *                     browscap.ini file is available.
     */
    public $remoteverurl = 'http://browscap.org/version';
    /**
     * @var $timeout: The timeout for the requests.
     */
    public $timeout = 5;
    /**
     * @var $updateinterval: The update interval in seconds.
     */
    public $updateinterval = 432000;
    /**
     * @var $errorinterval: The next update interval in seconds in case of an error.
     */
    public $errorinterval = 7200;
    /**
     * @var $doautoupdate: Flag to disable the automatic interval based update.
     */
    public $doautoupdate = true;
    /**
     * @var $updatemethod: The method to use to update the file, has to be a value of
     *                an UPDATE_* constant, null or false.
     */
    public $updatemethod = null;

    /**
     * The path of the local version of the browscap.ini file from which to
     * update (to be set only if used).
     *
     * @var string
     */
    public $localfile = null;

    /**
     * The useragent to include in the requests made by the class during the
     * update process.
     *
     * @var string
     */
    public $useragent = 'http://browscap.org/ - PHP Browscap/%v %m';

    /**
     * Flag to enable only lowercase indexes in the result.
     * The cache has to be rebuilt in order to apply this option.
     *
     * @var bool
     */
    public $lowercase = false;

    /**
     * Flag to enable/disable silent error management.
     * In case of an error during the update process the class returns an empty
     * array/object if the update process can't take place and the browscap.ini
     * file does not exist.
     *
     * @var bool
     */
    public $silent = false;

    /**
     * Where to store the cached PHP arrays.
     *
     * @var string
     */
    public $cachefilename = 'cache.php';

    /**
     * Where to store the downloaded ini file.
     *
     * @var string
     */
    public $inifilename = 'browscap.ini';

    /**
     * Path to the cache directory
     *
     * @var string
     */
    public $cachedir = null;

    /**
     * Flag to be set to true after loading the cache
     *
     * @var bool
     */
    protected $_cacheloaded = false;

    /**
     * Where to store the value of the included PHP cache file
     *
     * @var array
     */
    protected $_useragents = [];
    /**
     * Where to store browsers
     *
     * @var array
     */
    protected $_browsers = [];
    /**
     * Where to store patterns
     *
     * @var array
     */
    protected $_patterns = [];
    /**
     * Where to store properties
     *
     * @var array
     */
    protected $_properties = [];
    /**
     * Where to store the source version
     *
     * @var array
     */
    protected $_sourceversion;

    /**
     * Proxy settings stored as an associative array of associative arrays.
     *
     * This variable holds proxy settings in the format `$arr['wrapper']['option'] = $value`,
     * which are passed to `stream_context_create()` when building a stream resource.
     *
     * @var array
     * @see http://www.php.net/manual/en/function.stream-context-create.php
     */
    protected $_streamcontextoptions = [];


    /**
     * A valid context resource created with stream_context_create().
     *
     * @var resource
     * @see http://www.php.net/manual/en/function.stream-context-create.php
     */
    protected $_streamcontext = null;

    /**
     * Constructor class, checks for the existence of (and loads) the cache and
     * if needed updated the definitions
     *
     * @param string $cachedir
     *
     * @throws Exception
     */
    public function __construct($cachedir = null) {
        // Has to be set to reach E_STRICT compatibility, does not affect system/app settings.
        date_default_timezone_set(date_default_timezone_get());

        if (!isset($cachedir)) {
            throw new Exception(get_string('provide_pathfor_browscap', 'block_learnerscript'));
        }

        $oldcachedir = $cachedir;
        $cachedir     = realpath($cachedir);

        if (false === $cachedir) {
            throw new Exception(
                sprintf(
                    get_string('cannot_load_cachesfile', 'block_learnerscript'),
                    $oldcachedir
                )
            );
        }

        // Is the cache dir really the directory or is it directly the file?
        if (substr($cachedir, -4) === '.php') {
            $this->cachefilename = basename($cachedir);
            $this->cachedir      = dirname($cachedir);
        } else {
            $this->cachedir = $cachedir;
        }

        $this->cachedir .= DIRECTORY_SEPARATOR;
    }

    /**
     * Get the current source version
     * @return mixed
     */
    public function getsourceversion() {
        return $this->_sourceversion;
    }

    /**
     * Check if the cache needs to be updated
     * @return bool
     */
    public function shouldcachebeupdated() {
        // Load the cache at the first request.
        if ($this->_cacheloaded) {
            return false;
        }

        $cachefile = $this->cachedir . $this->cachefilename;
        $inifile   = $this->cachedir . $this->inifilename;

        // Set the interval only if needed.
        if ($this->doautoupdate && file_exists($inifile)) {
            $interval = time() - filemtime($inifile);
        } else {
            $interval = 0;
        }

        $shouldbeupdated = true;

        if (file_exists($cachefile) && file_exists($inifile) && ($interval <= $this->updateinterval)) {
            if ($this->loadcache($cachefile)) {
                $shouldbeupdated = false;
            }
        }

        return $shouldbeupdated;
    }

    /**
     * Gets the information about the browser by User Agent
     *
     * @param string $useragent   the user agent string
     * @param bool   $returnarray whether return an array or an object
     *
     * @throws Exception
     * @return \stdClass|array  the object containing the browsers details. Array if
     *                    $returnarray is set to true.
     */
    public function getbrowser($useragent = null, $returnarray = false) {
        if ($this->shouldcachebeupdated()) {
            try {
                $this->updatecache();
            } catch (Exception $e) {
                $inifile = $this->cachedir . $this->inifilename;

                if (file_exists($inifile)) {
                    // Adjust the filemtime to the $errorinterval.
                    touch($inifile, time() - $this->updateinterval + $this->errorinterval);
                } else if ($this->silent) {
                    // Return an array if silent mode is active and the ini db doesn't exsist.
                    return [];
                }

                if (!$this->silent) {
                    throw $e;
                }
            }
        }

        $cachefile = $this->cachedir . $this->cachefilename;
        if (!$this->_cacheloaded && !$this->loadcache($cachefile)) {
            throw new Exception(get_string('cannot_load_cachesfile', 'block_learnerscript'));
        }

        // Automatically detect the useragent.
        if (!isset($useragent)) {
            if (isset($_SERVER['HTTP_USER_AGENT'])) {
                $useragent = $_SERVER['HTTP_USER_AGENT'];
            } else {
                $useragent = '';
            }
        }

        $browser = [];

        $patterns = array_keys($this->_patterns);
        $chunks   = array_chunk($patterns, self::COUNT_PATTERN);

        foreach ($chunks as $chunk) {
            $longpattern = self::REGEX_DELIMITER
                . '^(?:' . implode(')|(?:', $chunk) . ')$'
                . self::REGEX_DELIMITER . 'i';

            if (!preg_match($longpattern, $useragent)) {
                continue;
            }

            foreach ($chunk as $pattern) {
                $patterntomatch = self::REGEX_DELIMITER . '^' . $pattern . '$' . self::REGEX_DELIMITER . 'i';
                $matches        = [];

                if (!preg_match($patterntomatch, $useragent, $matches)) {
                    continue;
                }

                $patterndata = $this->_patterns[$pattern];

                if (1 === count($matches)) {
                    // Standard match.
                    $key         = $patterndata;
                    $simplematch = true;
                } else {
                    $patterndata = unserialize($patterndata);

                    // Match with numeric replacements.
                    array_shift($matches);

                    $matchstring = self::COMPRESSION_PATTERN_START
                        . implode(self::COMPRESSION_PATTERN_DELIMITER, $matches);

                    if (!isset($patterndata[$matchstring])) {
                        // Partial match - numbers are not present, but everything else is ok.
                        continue;
                    }

                    $key = $patterndata[$matchstring];

                    $simplematch = false;
                }

                $browser = [
                    $useragent, // Original useragent.
                    trim(strtolower($pattern), self::REGEX_DELIMITER),
                    $this->pregunquote($pattern, $simplematch ? false : $matches),
                ];

                $browser = $value = $browser + unserialize($this->_browsers[$key]);

                while (array_key_exists(3, $value)) {
                    $value = unserialize($this->_browsers[$value[3]]);
                    $browser += $value;
                }

                if (!empty($browser[3]) && array_key_exists($browser[3], $this->_useragents)) {
                    $browser[3] = $this->_useragents[$browser[3]];
                }

                break 2;
            }
        }

        // Add the keys for each property.
        $array = [];
        foreach ($browser as $key => $value) {
            if ($value === 'true') {
                $value = true;
            } else if ($value === 'false') {
                $value = false;
            }

            $propertyname = $this->_properties[$key];

            if ($this->lowercase) {
                $propertyname = strtolower($propertyname);
            }

            $array[$propertyname] = $value;
        }

        return $returnarray ? $array : (object) $array;
    }

    /**
     * Load (auto-set) proxy settings from environment variables.
     */
    public function autodetectproxysettings() {
        $wrappers = ['http', 'https', 'ftp'];

        foreach ($wrappers as $wrapper) {
            $url = getenv($wrapper . '_proxy');
            if (!empty($url)) {
                $params = array_merge(
                    [
                        'port' => null,
                        'user' => null,
                        'pass' => null,
                    ],
                    parse_url($url)
                );
                $this->addproxysettings($params['host'], $params['port'], $wrapper, $params['user'], $params['pass']);
            }
        }
    }

    /**
     * Add proxy settings to the stream context array.
     *
     * @param string $server   Proxy server/host
     * @param int    $port     Port
     * @param string $wrapper  Wrapper: "http", "https", "ftp", others...
     * @param string $username Username (when requiring authentication)
     * @param string $password Password (when requiring authentication)
     *
     * @return Browscap
     */
    public function addproxysettings($server, $port = 3128, $wrapper = 'http', $username = null, $password = null) {
        $settings = [
            $wrapper => [
                'proxy'           => sprintf('tcp://%s:%d', $server, $port),
                'request_fulluri' => true,
                'timeout'         => $this->timeout,
            ],
        ];

        // Proxy authentication (optional).
        if (isset($username) && isset($password)) {
            $settings[$wrapper]['header'] =
            get_string('proxy_auth', 'block_learnerscript') . base64_encode($username . ':' . $password);
        }

        // Add these new settings to the stream context options array.
        $this->_streamcontextoptions = array_merge(
            $this->_streamcontextoptions,
            $settings
        );

        /* Return $this so we can chain addproxysettings() calls like this:
         * $browscap->
         *   addproxysettings('http')->
         *   addproxysettings('https')->
         *   addproxysettings('ftp');
         */
        return $this;
    }

    /**
     * Clear proxy settings from the stream context options array.
     *
     * @param string $wrapper Remove settings from this wrapper only
     *
     * @return array Wrappers cleared
     */
    public function clearproxysettings($wrapper = null) {
        $wrappers = isset($wrapper) ? [$wrapper] : array_keys($this->_streamcontextoptions);

        $clearedwrappers = [];
        $options         = ['proxy', 'request_fulluri', 'header'];
        foreach ($wrappers as $wrapper) {

            // Remove wrapper options related to proxy settings.
            if (isset($this->_streamcontextoptions[$wrapper]['proxy'])) {
                foreach ($options as $option) {
                    unset($this->_streamcontextoptions[$wrapper][$option]);
                }

                // Remove wrapper entry if there are no other options left.
                if (empty($this->_streamcontextoptions[$wrapper])) {
                    unset($this->_streamcontextoptions[$wrapper]);
                }

                $clearedwrappers[] = $wrapper;
            }
        }

        return $clearedwrappers;
    }

    /**
     * Returns the array of stream context options.
     *
     * @return array
     */
    public function getstreamcontextoptions() {
        $streamcontextoptions = $this->_streamcontextoptions;

        if (empty($streamcontextoptions)) {
            // Set default context, including timeout.
            $streamcontextoptions = [
                'http' => [
                    'timeout' => $this->timeout,
                ],
            ];
        }

        return $streamcontextoptions;
    }

    /**
     * Parses the ini file and updates the cache files
     *
     * @throws Exception
     * @return bool whether the file was correctly written to the disk
     */
    public function updatecache() {
        $lockfile = $this->cachedir . 'cache.lock';

        $lockres = fopen($lockfile, 'w+');
        if (false === $lockres) {
            throw new Exception(sprintf('error opening lockfile %s', $lockfile));
        }
        if (false === flock($lockres, LOCK_EX | LOCK_NB)) {
            throw new Exception(sprintf('error locking lockfile %s', $lockfile));
        }

        $inipath   = $this->cachedir . $this->inifilename;
        $cachepath = $this->cachedir . $this->cachefilename;

        // Choose the right url.
        if ($this->getupdatemethod() == self::UPDATE_LOCAL) {
            $url = realpath($this->localfile);
        } else {
            $url = $this->remoteiniurl;
        }

        $this->getremoteinifile($url, $inipath);

        $this->_properties = [];
        $this->_browsers   = [];
        $this->_useragents = [];
        $this->_patterns   = [];

        $inicontent = file_get_contents($inipath);
        $this->createcachenewway($inicontent);

        // Write out new cache file.
        $dir = dirname($cachepath);
        $tmpfile = $dir . '/temp_' . md5(time() . basename($cachepath));

        // Asume that all will be ok.
        if (false === ($fileres = fopen($tmpfile, 'w+'))) {
            // Opening the temparary file failed.
            throw new Exception(get_string('failed_open_tempfile','block_learnerscript'));
        }

        if (false === fwrite($fileres, $this->buildcache())) {
            // Writing to the temparary file failed.
            throw new Exception(get_string('writing_failed','block_learnerscript'));
        }

        fclose($fileres);

        if (false === rename($tmpfile, $cachepath)) {
            // Renaming file failed, remove temp file.
            @unlink($tmpfile);

            throw new Exception(get_string('couldnt_rename_tempfile','block_learnerscript'));
        }

        @flock($lockres, LOCK_UN);
        @fclose($lockres);
        @unlink($lockfile);
        $this->_cacheloaded = false;

        return true;
    }

    /**
     * creates the cache content
     *
     * @param string $inicontent The content of the downloaded ini file
     * @param bool   $actlikenewersion
     */
    protected function createcacheoldway($inicontent, $actlikenewersion = false) {
        $browsers = parse_ini_string($inicontent, true, INI_SCANNER_RAW);

        if ($actlikenewersion) {
            $this->_sourceversion = (int) $browsers[self::BROWSCAP_VERSION_KEY]['Version'];
        } else {
            $this->_sourceversion = $browsers[self::BROWSCAP_VERSION_KEY]['Version'];
        }

        unset($browsers[self::BROWSCAP_VERSION_KEY]);

        if (!$actlikenewersion) {
            unset($browsers['DefaultProperties']['RenderingEngine_Description']);
        }

        $this->_properties = array_keys($browsers['DefaultProperties']);

        array_unshift(
            $this->_properties,
            'browser_name',
            'browser_name_regex',
            'browser_name_pattern',
            'Parent'
        );

        $tmpuseragents = array_keys($browsers);

        usort($tmpuseragents, [$this, 'comparebcstrings']);

        $useragentskeys = array_flip($tmpuseragents);
        $propertieskeys = array_flip($this->_properties);
        $tmppatterns    = [];

        foreach ($tmpuseragents as $i => $useragent) {
            $properties = $browsers[$useragent];

            if (empty($properties['Comment'])
                || false !== strpos($useragent, '*')
                || false !== strpos($useragent, '?')
            ) {
                $pattern = $this->pregquote($useragent);

                $countmatches = preg_match_all(
                    self::REGEX_DELIMITER . '\d' . self::REGEX_DELIMITER,
                    $pattern,
                    $matches
                );

                if (!$countmatches) {
                    $tmppatterns[$pattern] = $i;
                } else {
                    $compressedpattern = preg_replace(
                        self::REGEX_DELIMITER . '\d' . self::REGEX_DELIMITER,
                        '(\d)',
                        $pattern
                    );

                    if (!isset($tmppatterns[$compressedpattern])) {
                        $tmppatterns[$compressedpattern] = ['first' => $pattern];
                    }

                    $tmppatterns[$compressedpattern][$i] = $matches[0];
                }
            }

            if (!empty($properties['Parent'])) {
                $parent = $properties['Parent'];

                $parentkey = $useragentskeys[$parent];

                $properties['Parent']                 = $parentkey;
                $this->_useragents[$parentkey . '.0'] = $tmpuseragents[$parentkey];
            };

            $this->_browsers[] = $this->resortproperties($properties, $propertieskeys);
        }

        // Reducing memory usage by unsetting $tmp_useragents.
        unset($tmpuseragents);

        $this->_patterns = $this->deduplicatepattern($tmppatterns);
    }

    /**
     * creates the cache content
     *
     * @param string $inicontent The content of the downloaded ini file
     *
     * @throws \phpbrowscap\Exception
     */
    protected function createcachenewway($inicontent) {
        $patternpositions = [];

        // Get all patterns from the ini file in the correct order,
        // So that we can calculate with index number of the resulting array,
        // Which part to use when the ini file is split into its sections.
        preg_match_all('/(?<=\[)(?:[^\r\n]+)(?=\])/m', $inicontent, $patternpositions);

        if (!isset($patternpositions[0])) {
            throw new Exception(get_string('couldnt_extract_pattern','block_learnerscript'));
        }

        $patternpositions = $patternpositions[0];

        if (!count($patternpositions)) {
            throw new Exception(get_string('pattern_notfound','block_learnerscript'));
        }

        // Split the ini file into sections and save the data in one line with a hash of the belonging.
        // Pattern (filtered in the previous step).
        $iniparts       = preg_split('/\[[^\r\n]+\]/', $inicontent);
        $tmppatterns    = [];
        $propertieskeys = [];
        $matches        = [];

        if (preg_match('/.*\[DefaultProperties\]([^[]*).*/', $inicontent, $matches)) {
            $properties = parse_ini_string($matches[1], true, INI_SCANNER_RAW);

            $this->_properties = array_keys($properties);

            array_unshift(
                $this->_properties,
                'browser_name',
                'browser_name_regex',
                'browser_name_pattern',
                'Parent'
            );

            $propertieskeys = array_flip($this->_properties);
        }

        $key                   = $this->pregquote(self::BROWSCAP_VERSION_KEY);
        $this->_sourceversion = 0;
        $matches               = [];

        if (preg_match("/\\.*[" . $key . "\\][^[]*Version=(\\d+)\\D.*/", $inicontent, $matches)) {
            if (isset($matches[1])) {
                $this->_sourceversion = (int)$matches[1];
            }
        }

        $useragentskeys = array_flip($patternpositions);
        foreach ($patternpositions as $position => $useragent) {
            if (self::BROWSCAP_VERSION_KEY === $useragent) {
                continue;
            }

            $properties = parse_ini_string($iniparts[($position + 1)], true, INI_SCANNER_RAW);

            if (empty($properties['Comment'])
                || false !== strpos($useragent, '*')
                || false !== strpos($useragent, '?')
            ) {
                $pattern      = $this->pregquote(strtolower($useragent));
                $matches      = [];
                $i            = $position - 1;
                $countmatches = preg_match_all(
                    self::REGEX_DELIMITER . '\d' . self::REGEX_DELIMITER,
                    $pattern,
                    $matches
                );

                if (!$countmatches) {
                    $tmppatterns[$pattern] = $i;
                } else {
                    $compressedpattern = preg_replace(
                        self::REGEX_DELIMITER . '\d' . self::REGEX_DELIMITER,
                        '(\d)',
                        $pattern
                    );

                    if (!isset($tmppatterns[$compressedpattern])) {
                        $tmppatterns[$compressedpattern] = ['first' => $pattern];
                    }

                    $tmppatterns[$compressedpattern][$i] = $matches[0];
                }
            }

            if (!empty($properties['Parent'])) {
                $parent    = $properties['Parent'];
                $parentkey = $useragentskeys[$parent];

                $properties['Parent']                       = $parentkey - 1;
                $this->_useragents[($parentkey - 1) . '.0'] = $patternpositions[$parentkey];
            };
            if ($properties == false) {
                $properties = [];
            }
            $this->_browsers[] = $this->resortproperties($properties, $propertieskeys);
        }

        $patternlist = $this->deduplicatepattern($tmppatterns);

        $positionindex = [];
        $lengthindex   = [];
        $shortlength   = [];
        $patternarray  = [];
        $counter       = 0;

        foreach (array_keys($patternlist) as $pattern) {
            $decodedpattern = str_replace('(\d)', 0, $this->pregunquote($pattern, false));

            // Force "defaultproperties" (if available) to first position, and "*" to last position.
            if ($decodedpattern === 'defaultproperties') {
                $positionindex[$pattern] = 0;
            } else if ($decodedpattern === '*') {
                $positionindex[$pattern] = 2;
            } else {
                $positionindex[$pattern] = 1;
            }

            // Sort by length.
            $lengthindex[$pattern] = strlen($decodedpattern);
            $shortlength[$pattern] = strlen(str_replace(['*', '?'], '', $decodedpattern));

            // Sort by original order.
            $patternarray[$pattern] = $counter;

            $counter++;
        }

        array_multisort(
            $positionindex,
            SORT_ASC,
            SORT_NUMERIC,
            $lengthindex,
            SORT_DESC,
            SORT_NUMERIC,
            $shortlength,
            SORT_DESC,
            SORT_NUMERIC,
            $patternarray,
            SORT_ASC,
            SORT_NUMERIC,
            $patternlist
        );

        $this->_patterns = $patternlist;
    }

    /**
     * Sort the properties by keys
     * @param array $properties
     * @param array $propertieskeys
     *
     * @return array
     */
    protected function resortproperties(array $properties, array $propertieskeys) {
        $browser = [];

        foreach ($properties as $propertyname => $propertyvalue) {
            if (!isset($propertieskeys[$propertyname])) {
                continue;
            }

            $browser[$propertieskeys[$propertyname]] = $propertyvalue;
        }

        return $browser;
    }

    /**
     * Deduplicate Patterns
     * @param array $tmppatterns
     *
     * @return array
     */
    protected function deduplicatepattern(array $tmppatterns) {
        $patternlist = [];

        foreach ($tmppatterns as $pattern => $patterndata) {
            if (is_int($patterndata)) {
                $data = $patterndata;
            } else if (2 == count($patterndata)) {
                end($patterndata);

                $pattern = $patterndata['first'];
                $data    = key($patterndata);
            } else {
                unset($patterndata['first']);

                $data = $this->deduplicatecompressionpattern($patterndata, $pattern);
            }

            $patternlist[$pattern] = $data;
        }

        return $patternlist;
    }

    /**
     * Compare function for strings
     * @param string $a
     * @param string $b
     *
     * @return int
     */
    protected function comparebcstrings($a, $b) {
        $alen = strlen($a);
        $blen = strlen($b);

        if ($alen > $blen) {
            return -1;
        }

        if ($alen < $blen) {
            return 1;
        }

        $alen = strlen(str_replace(['*', '?'], '', $a));
        $blen = strlen(str_replace(['*', '?'], '', $b));

        if ($alen > $blen) {
            return -1;
        }

        if ($alen < $blen) {
            return 1;
        }

        return 0;
    }

    /**
     * That looks complicated...
     *
     * All numbers are taken out into $matches, so we check if any of those numbers are identical
     * in all the $matches and if they are we restore them to the $pattern, removing from the $matches.
     * This gives us patterns with "(\d)" only in places that differ for some matches.
     *
     * @param array  $matches
     * @param string $pattern
     *
     * @return array of $matches
     */
    protected function deduplicatecompressionpattern($matches, &$pattern) {
        $tmpmatches = $matches;
        $firstmatch = array_shift($tmpmatches);
        $differences = [];

        foreach ($tmpmatches as $somematch) {
            $differences += array_diff_assoc($firstmatch, $somematch);
        }

        $identical = array_diff_key($firstmatch, $differences);

        $preparedmatches = [];

        foreach ($matches as $i => $somematch) {
            $key = self::COMPRESSION_PATTERN_START
                . implode(self::COMPRESSION_PATTERN_DELIMITER, array_diff_assoc($somematch, $identical));

            $preparedmatches[$key] = $i;
        }

        $patternparts = explode('(\d)', $pattern);

        foreach ($identical as $position => $value) {
            $patternparts[$position + 1] = $patternparts[$position] . $value . $patternparts[$position + 1];
            unset($patternparts[$position]);
        }

        $pattern = implode('(\d)', $patternparts);

        return $preparedmatches;
    }

    /**
     * Converts browscap match patterns into preg match patterns.
     *
     * @param string $useragent
     *
     * @return string
     */
    protected function pregquote($useragent) {
        $pattern = preg_quote($useragent, self::REGEX_DELIMITER);
        return str_replace(
            ['\*', '\?', '\\x'],
            ['.*', '.', '\\\\x'],
            $pattern
        );
    }

    /**
     * Converts preg match patterns back to browscap match patterns.
     *
     * @param string        $pattern
     * @param array|boolean $matches
     *
     * @return string
     */
    protected function pregunquote($pattern, $matches) {
        // List of escaped characters: http://www.php.net/manual/en/function.preg-quote.php
        // To properly unescape '?' which was changed to '.', I replace '\.' (real dot) with '\?',
        // Then change '.' to '?' and then '\?' to '.'.
        $search  = [
            '\\' . self::REGEX_DELIMITER, '\\.', '\\\\', '\\+', '\\[', '\\^', '\\]', '\\$', '\\(', '\\)', '\\{', '\\}',
            '\\=', '\\!', '\\<', '\\>', '\\|', '\\:', '\\-', '.*', '.', '\\?',
        ];
        $replace = [
            self::REGEX_DELIMITER, '\\?', '\\', '+', '[', '^', ']', '$', '(', ')', '{', '}', '=', '!', '<', '>', '|',
            ':', '-', '*', '?', '.',
        ];

        $result = substr(str_replace($search, $replace, $pattern), 2, -2);

        if ($matches) {
            foreach ($matches as $onematch) {
                $position = strpos($result, '(\d)');
                $result   = substr_replace($result, $onematch, $position, 4);
            }
        }

        return $result;
    }

    /**
     * Loads the cache into object's properties
     *
     * @param string $cachefile
     *
     * @return bool
     */
    protected function loadcache($cachefile) {
        $cacheversion  = null;
        $sourceversion = null;
        $browsers       = [];
        $useragents     = [];
        $patterns       = [];
        $properties     = [];

        $this->_cacheloaded = false;

        require($cachefile);

        if (!isset($cacheversion) || $cacheversion != self::CACHE_FILE_VERSION) {
            return false;
        }

        $this->_sourceversion = $sourceversion;
        $this->_browsers       = $browsers;
        $this->_useragents     = $useragents;
        $this->_patterns       = $patterns;
        $this->_properties     = $properties;

        $this->_cacheloaded = true;

        return true;
    }

    /**
     * Parses the array to cache and writes the resulting PHP string to disk
     *
     * @return string False on write error, true otherwise
     */
    protected function buildcache() {
        $content = sprintf(
            "<?php\n\$sourceversion=%s;\n\$cacheversion=%s",
            "'" . $this->_sourceversion . "'",
            "'" . self::CACHE_FILE_VERSION . "'"
        );

        $content .= ";\n\$properties=";
        $content .= $this->array2string($this->_properties);

        $content .= ";\n\$browsers=";
        $content .= $this->array2string($this->_browsers);

        $content .= ";\n\$useragents=";
        $content .= $this->array2string($this->_useragents);

        $content .= ";\n\$patterns=";
        $content .= $this->array2string($this->_patterns) . ";\n";

        return $content;
    }

    /**
     * Lazy getter for the stream context resource.
     *
     * @param bool $recreate
     *
     * @return resource
     */
    protected function getstreamcontext($recreate = false) {
        if (!isset($this->_streamcontext) || true === $recreate) {
            $this->_streamcontext = stream_context_create($this->getstreamcontextoptions());
        }

        return $this->_streamcontext;
    }

    /**
     * Updates the local copy of the ini file (by version checking) and adapts
     * his syntax to the PHP ini parser
     *
     * @param string $url  the url of the remote server
     * @param string $path the path of the ini file to update
     *
     * @throws Exception
     * @return bool if the ini file was updated
     */
    protected function getremoteinifile($url, $path) {
        // Local and remote file are the same, no update possible.
        if ($url == $path) {
            return false;
        }

        // Check version.
        if (file_exists($path) && filesize($path)) {
            $localtmstp = filemtime($path);

            if ($this->getupdatemethod() == self::UPDATE_LOCAL) {
                $remotetmstp = $this->getlocalmtime();
            } else {
                $remotetmstp = $this->getremotemtime();
            }

            if ($remotetmstp <= $localtmstp) {
                // No update needed, return.
                touch($path);

                return false;
            }
        }

        // Check if it's possible to write to the .ini file.
        if (is_file($path)) {
            if (!is_writable($path)) {
                throw new Exception(
                    get_string('couldnt_write', 'block_learnerscript') . $path . get_string('check_permissions_ini', 'block_learnerscript')
                );
            }
        } else {
            // Test writability by creating a file only if one already doesn't exist, so we can safely delete it after
            // the test.
            $testfile = fopen($path, 'a');
            if ($testfile) {
                fclose($testfile);
                unlink($path);
            } else {
                throw new Exception(
                    get_string('couldnt_write', 'block_learnerscript') . $path . get_string('check_permissions_cache', 'block_learnerscript')
                );
            }
        }

        // Get updated .ini file.
        $content = $this->getremotedata($url);

        if (!is_string($content) || strlen($content) < 1) {
            throw new Exception(get_string('couldnt_load_ini', 'block_learnerscript') . $url);
        }

        if (false !== strpos('rate limit', $content)) {
            throw new Exception(
                get_string('couldnt_load_ini', 'block_learnerscript') . $url . get_string('ip_limit_exeeded', 'block_learnerscript')
            );
        }

        // Replace opening and closing php and asp tags.
        $content = $this->sanitizecontent($content);

        if (!file_put_contents($path, $content)) {
            throw new Exception(get_string('couldnt_write_ini', 'block_learnerscript') . $path);
        }

        return true;
    }

    /**
     * Sanitize conten by regex
     * @param string $content
     *
     * @return mixed
     */
    protected function sanitizecontent($content) {
        // Replace everything between opening and closing php and asp tags.
        $content = preg_replace('/<[?%].*[?%]>/', '', $content);

        // Replace opening and closing php and asp tags.
        return str_replace(['<?', '<%', '?>', '%>'], '', $content);
    }

    /**
     * Gets the remote ini file update timestamp
     *
     * @throws Exception
     * @return int the remote modification timestamp
     */
    protected function getremotemtime() {
        $remotedatetime = $this->getremotedata($this->remoteverurl);
        $remotetmstp    = strtotime($remotedatetime);

        if (!$remotetmstp) {
            throw new Exception(get_string('bad_datetime_format', 'block_learnerscript') . " {$this->remoteverurl}");
        }

        return $remotetmstp;
    }

    /**
     * Gets the local ini file update timestamp
     *
     * @throws Exception
     * @return int the local modification timestamp
     */
    protected function getlocalmtime() {
        if (!is_readable($this->localfile) || !is_file($this->localfile)) {
            throw new Exception(get_string("localfile_not_readable", 'block_learnerscript'));
        }

        return filemtime($this->localfile);
    }

    /**
     * Converts the given array to the PHP string which represent it.
     * This method optimizes the PHP code and the output differs form the
     * var_export one as the internal PHP function does not strip whitespace or
     * convert strings to numbers.
     *
     * @param array $array The array to parse and convert
     *
     * @return string False on write error, true otherwise
     */
    protected function array2string($array) {
        $content = "array(\n";

        foreach ($array as $key => $value) {
            if (is_int($key)) {
                $key = '';
            } else if (ctype_digit((string) $key)) {
                $key = intval($key) . ' => ';
            } else if ('.0' === substr($key, -2) && !preg_match('/[^\d\.]/', $key)) {
                $key = intval($key) . ' => ';
            } else {
                $key = "'" . str_replace("'", "\'", $key) . "' => ";
            }

            if (is_array($value)) {
                $value = "'" . addcslashes(serialize($value), "'") . "'";
            } else if (ctype_digit((string) $value)) {
                $value = intval($value);
            } else {
                $value = "'" . str_replace("'", "\'", $value) . "'";
            }

            $content .= $key . $value . ",\n";
        }

        $content .= "\n)";

        return $content;
    }

    /**
     * Checks for the various possibilities offered by the current configuration
     * of PHP to retrieve external HTTP data
     *
     * @return string|false the name of function to use to retrieve the file or false if no methods are available
     */
    protected function getupdatemethod() {
        // Caches the result.
        if ($this->updatemethod === null) {
            if ($this->localfile !== null) {
                $this->updatemethod = self::UPDATE_LOCAL;
            } else if (ini_get('allow_url_fopen') && function_exists('file_get_contents')) {
                $this->updatemethod = self::UPDATE_FOPEN;
            } else if (function_exists('fsockopen')) {
                $this->updatemethod = self::UPDATE_FSOCKOPEN;
            } else if (extension_loaded('curl')) {
                $this->updatemethod = self::UPDATE_CURL;
            } else {
                $this->updatemethod = false;
            }
        }

        return $this->updatemethod;
    }

    /**
     * Retrieve the data identified by the URL
     *
     * @param string $url the url of the data
     *
     * @throws Exception
     * @return string the retrieved data
     */
    protected function getremotedata($url) {
        ini_set('useragent', $this->getuseragent());
        ini_set('memory_limit', -1);

        switch ($this->getupdatemethod()) {
            case self::UPDATE_LOCAL:
                $file = file_get_contents($url);

                if ($file !== false) {
                    return $file;
                } else {
                    throw new Exception(get_string('cannt_opens_localfile', 'block_learnerscript'));
                }
            case self::UPDATE_FOPEN:
                if (ini_get('allow_url_fopen') && function_exists('file_get_contents')) {
                    // Include proxy settings in the file_get_contents() call.
                    $context = $this->getstreamcontext();
                    $file    = file_get_contents($url, false, $context);

                    if ($file !== false) {
                        return $file;
                    }
                }// Else try with the next possibility (break omitted).
            case self::UPDATE_FSOCKOPEN:
                if (function_exists('fsockopen')) {
                    $remoteurl     = parse_url($url);
                    $contextoptions = $this->getstreamcontextoptions();

                    $errno  = 0;
                    $errstr = '';

                    if (empty($contextoptions)) {
                        $port           = (empty($remoteurl['port']) ? 80 : $remoteurl['port']);
                        $remotehandler = fsockopen($remoteurl['host'], $port, $errno, $errstr, $this->timeout);
                    } else {
                        $context = $this->getstreamcontext();

                        $remotehandler = stream_socket_client(
                            $url,
                            $errno,
                            $errstr,
                            $this->timeout,
                            STREAM_CLIENT_CONNECT,
                            $context
                        );
                    }

                    if ($remotehandler) {
                        stream_set_timeout($remotehandler, $this->timeout);

                        if (isset($remoteurl['query'])) {
                            $remoteurl['path'] .= '?' . $remoteurl['query'];
                        }

                        $out = sprintf(
                            self::REQUEST_HEADERS,
                            $remoteurl['path'],
                            $remoteurl['host'],
                            $this->getuseragent()
                        );

                        fwrite($remotehandler, $out);

                        $response = fgets($remotehandler);
                        if (strpos($response, '200 OK') !== false) {
                            $file = '';
                            while (!feof($remotehandler)) {
                                $file .= fgets($remotehandler);
                            }

                            $file = str_replace("\r\n", "\n", $file);
                            $file = explode("\n\n", $file);
                            array_shift($file);

                            $file = implode("\n\n", $file);

                            fclose($remotehandler);

                            return $file;
                        }
                    }
                }// Else try with the next possibility.
            case self::UPDATE_CURL:
                if (extension_loaded('curl')) { // Make sure curl is loaded.
                    $ch = curl_init($url);

                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $this->timeout);
                    curl_setopt($ch, CURLOPT_USERAGENT, $this->getuseragent());

                    $file = curl_exec($ch);

                    curl_close($ch);

                    if ($file !== false) {
                        return $file;
                    }
                }// Else try with the next possibility.
            case false:
                throw new Exception(
                    get_string('cannt_connect_extenals', 'block_learnerscript')
                );
        }

        return '';
    }

    /**
     * Format the useragent string to be used in the remote requests made by the
     * class during the update process.
     *
     * @return string the formatted user agent
     */
    protected function getuseragent() {
        $ua = str_replace('%v', self::VERSION, $this->useragent);
        $ua = str_replace('%m', $this->getupdatemethod(), $ua);

        return $ua;
    }
}
